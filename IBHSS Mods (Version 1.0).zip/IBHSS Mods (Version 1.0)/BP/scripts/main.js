import { world, system } from "@minecraft/server";

const objLeftClick = world.scoreboard.getObjective("detect:left_click") ?? world.scoreboard.addObjective("detect:left_click");
const objRightClick = world.scoreboard.getObjective("detect:right_click") ?? world.scoreboard.addObjective("detect:right_click");
world.scoreboard.getObjective("detect:right_click_timer") ?? world.scoreboard.addObjective("detect:right_click_timer");

// Detect Right and Left Click Events
const rightClickOnBlock = world.beforeEvents.playerInteractWithBlock.subscribe(ev => {
    const { player, isFirstEvent } = ev;
    if (!isFirstEvent) return;
    if (rightClickOnBlock) {
        system.run(() => {
            objRightClick.setScore(player, 1);
        });
    }
});

const rightClickOnEntity = world.beforeEvents.playerInteractWithEntity.subscribe(({ player }) => {
    if (rightClickOnEntity) {
        system.run(() => {
            objRightClick.setScore(player, 1);
        });
    }
});

const rightClickAfter = world.afterEvents.itemUse.subscribe(({ source }) => {
    if (source.typeId !== 'minecraft:player') return;
    if (rightClickAfter) {
        objRightClick.setScore(source, 1);
    }
});

const rightClickPlaceBlock = world.afterEvents.playerPlaceBlock.subscribe(({ player }) => {
    if (player.typeId !== 'minecraft:player') return;
    if (rightClickPlaceBlock) {
        objRightClick.setScore(player, 1);
    }
});

const leftClick = system.afterEvents.scriptEventReceive.subscribe(({ sourceEntity: player, id }) => {
    if (id != 'script:swing') return;
    if (leftClick) {
        objLeftClick.setScore(player, 1);
    }
});

function detectClick() {
    for (const player of world.getPlayers()) {
        objLeftClick.setScore(player, 0);
        objRightClick.setScore(player, 0);
    }
}
system.runInterval(detectClick, 1);