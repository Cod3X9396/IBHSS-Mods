scoreboard players add @a[scores={detect:right_click_timer=0..5}] detect:right_click_timer 1
scoreboard players reset @a[scores={detect:right_click_timer=6..}] detect:right_click_timer