scoreboard players set @a[scores={detect:right_click=1}] detect:right_click_timer 0
execute as @a[scores={detect:right_click_timer=0..}] run function right_click_timer